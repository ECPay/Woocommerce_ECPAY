<?php
return [
    [
        'title' => '尚未啟用綠界電子發票',
        'desc'  => '請前往<a href="' . admin_url( 'admin.php?page=wc-settings&tab=wooecpay_setting&section=ecpay_main' ) . '">設定</a>',
        'id'    => 'empty_options',
        'type'  => 'title',
    ],
];